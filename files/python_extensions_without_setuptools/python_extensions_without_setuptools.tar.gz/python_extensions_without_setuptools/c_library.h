#pragma once

// This is a C library. We can call it from C or use the python bindings

void f(void);
