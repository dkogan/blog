#!/usr/bin/python2

import project.pymodule
import project.c_library

project.c_library.f()
project.pymodule .g()
